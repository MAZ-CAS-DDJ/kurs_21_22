**INSTALL ANACONDA**

1. [Anaconda-Package](https://www.anaconda.com/products/individual/get-started) herunterladen
2. Graphical Interface installieren
3. Anaconda Cloud Account erstellen
4. Anaconda Navigator starten
5. "Launch" Jupyter Notebook. Das Terminal starten und Jupyter Notebook öffnet im Browser. Ihr seht nun die File-Struktur auf eben der Ebene, auf der sich Jupyter Notebook installiert hat.
6. Zum "Desktop" Navigieren
7. "New", "Python 3". Und es tut sich ein neues Arbeitsfeld auf, das in der Bedienung identisch ist zu Google Colab.
