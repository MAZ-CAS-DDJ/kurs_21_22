## 03 Workflow

Es macht Sinn, wenn man sich auf seinem persönlichen Notebook ganz bewusst einen Workflow zurecht legt, um auf all die unterschiedlichen Programme, die nun zum Einsatz kommen, möglichst effizient zuzugreifen.

Hilfreich sind auf dem Mac etwa die [Multi-Touch Gestures](https://support.apple.com/en-us/HT204895). Die gibt es natürlich auch auf anderen Betriebssystemen und anderer Hardware, sie sind sicherlich etwas anders. Aber es lohnt sich, diese mal genauer anzuschauen,

Meine ganz persönliche Organisation:

- Rechte Spalte mit den wichtigsten Apps. Klein. Am unteren Bildschirmrand greife ich nicht gerne darauf zu.
- Vollbildschirm für Browser. Wichtige Tabs fixieren
- Dreifinger-Swipe nach oben, um Desktop zu wechseln. Immer so 4 bis 6 Desktops im Einsatz. Einer für alles Kleingemüse. Und
- Dreifinger-Swipe, links und rechts.
- Tools: Atom, Notizblock, Slack, Evernote, Dropbox, Chrome, Terminal, Finder, Launchpad, Anaconda. 
