# 02 Jupyter Notebook

Ihr habt in den letzten drei Tagen mit Google Colab gearbeitet. Dieses System ist deshalb so praktisch, weil es sich gänzlich in der Cloud befindet und deshalb für alle Computer via ihrem Browser identisch bedient werden kann.

Doch wenn es um das Einlesen und Auslesen von Dokumenten und Daten geht, ist Colab weniger praktisch, weil ja auch diese Daten in der Cloud hin- und hergeschoben werden müssen. Damit das effizienter und auch einfacher geschehen kann, dafür haben wir jetzt mithilfe von Anaconda Jupyter Notebook lokal installiert.

Von der Bedienung her ist es identisch. Es funktioniert sogar im Browser. Aber eben nicht in der Cloud. Sondern lokal auf unserem Gerät mit Zugriff auf alle lokalen Files. Ihr könnt, wie ihr das kennt, auch mit Doppelklicks hin- und hernavigieren.

Und auch Jupyter Notebooks hat zwei Modi: MarkDown und Code.

Das Abspeichern von Jupyter Notebook ist besonders praktish. Ihr könnt es als Jupyter Notebook oder direkt als Python-Code und in diversen anderen Formaten.

Wenn ihr wissen wollt, wie der Jupyter Notebook Code genau aussieht, könnt ihr das bei Atom anschauen.
